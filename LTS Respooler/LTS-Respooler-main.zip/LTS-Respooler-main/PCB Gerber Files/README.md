Here you can find the Manufacturing data for all the available PCB boards. Feel free to order your own PCBs! They are optimized to be ordered from JLCPCB (https://jlcpcb.com).
